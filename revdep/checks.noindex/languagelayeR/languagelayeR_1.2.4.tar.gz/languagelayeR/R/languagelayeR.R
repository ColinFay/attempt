#' languagelayeR
#' 
#' Access the 'languagelayer' API.
#' 
#' @details For more info \code{browseVignettes("languagelayeR")}.
#' 
#' @name languagelayeR

NULL