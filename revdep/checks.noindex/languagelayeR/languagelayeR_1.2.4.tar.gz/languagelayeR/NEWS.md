---
title: "NEWS"
output: html_document
---

## languagelayeR 1.2.0

Old deprecated functions are not available anymore.

## languagelayeR 1.1.0

`setApiKey` is now deprecated
`getSupportedLanguage` is now `get_supported_lang`
`getLanguage` is now `get_lang`