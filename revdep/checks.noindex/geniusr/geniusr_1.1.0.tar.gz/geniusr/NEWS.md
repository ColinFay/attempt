# geniusr 1.1.0

* Correct license added.
* Fixed a bug occuring in `get_song_meta` functions to handle missing song fields (#6).
* Fixed a bug in `scrape_lyrics_` functions to handle instrumental songs (#8).

# geniusr 1.0.0

* CRAN release
* Added a `NEWS.md` file to track changes to the package.
