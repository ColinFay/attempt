# tidystringdist 0.1.0
2018-10

- Added ellipsis to `tidy_stringdist()` for passing additional arguments to `stringdist::stringdist()`
- Fixed issue with custom column names in `tidy_stringdist()`. See #6

2018-01

- `stringsAsFactors` removed

2017-10-26

- Compute several methods is now possible. 

2017-10 

- Col name in output is now the name of the method used. 

* first commit



