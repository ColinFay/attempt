globalVariables(
  list(
    "name",
    "id",
    "label",
    "properties"
  )
)
